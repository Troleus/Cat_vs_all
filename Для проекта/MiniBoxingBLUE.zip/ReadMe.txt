if you like, support me :D
get full assets, here :
https://gshelper.com/product/mini-boxing-game-sprites/

Regards, Segel2D