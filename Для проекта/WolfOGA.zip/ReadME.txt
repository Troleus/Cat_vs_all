Just want to share wolf game character with a chibi style, with animations (Idle, Walk, Attack, Hurt, and Dead)
I hope you like it

Need more? Get full assets here : http://bit.ly/2RjaQQ8

By. Segel2D