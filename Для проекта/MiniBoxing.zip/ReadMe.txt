if you like, support me :D
get full assets, here :
https://graphicriver.net/item/mini-boxing-characters/22352478

Regards, Segel2D